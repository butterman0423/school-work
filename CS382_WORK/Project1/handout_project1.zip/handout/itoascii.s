
/*  
    Name:
    Pledge: 
 */

.global itoascii

itoascii:



.data
    /* Put the converted string into buffer,
       and return the address of buffer */
    buffer: .fill 128, 1, 0


